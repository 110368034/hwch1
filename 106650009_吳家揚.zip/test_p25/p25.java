public class p25{
    public static void main(String[] args)
    {
    int num;
    num=3;
    System.out.println("變數num的值是"+num);
    }
    }

