
public class p18{

    public static void main(String[] arg)
    {
    
    System.out.println("顯示出反斜線:\\");
    System.out.println("顯示出單引號\'");
    }
    }