public class p16{
    public static void main(String[] args)
    {
    System.out.println('A');
    System.out.println("開始使用Java吧!");
    System.out.println(123);
    }
    }