public class p27{
    
    public static void main(String[]args)
    {
    int num1,num2;
    num1=3;
    
    System.out.println("變數num1的值是"+num1);
    num2=num1;
    System.out.println("將變數num1指定到變數num2之中");
    System.out.println("變數num2的值是"+num2);
    }
    }